#define _POSIX_C_SOURCE 200809L
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_STR 256

typedef struct {
    char buf[MAX_STR];

    pthread_mutex_t mtx;
    pthread_cond_t  cv_lida;       // sinaliza "string já foi lida"
    pthread_cond_t  cv_convertida; // sinaliza "string já foi convertida"

    int lida;
    int convertida;
} shared_t;

static void remove_newline(char *s) {
    size_t n = strlen(s);
    if (n > 0 && s[n - 1] == '\n') s[n - 1] = '\0';
}

void *thread_leitura(void *arg) {
    shared_t *sh = (shared_t *)arg;

    // Leitura (fora do lock, para não bloquear os outros desnecessariamente)
    char local[MAX_STR];

    printf("Introduza uma string: ");
    fflush(stdout);

    if (!fgets(local, sizeof(local), stdin)) {
        // EOF/erro: produzir string vazia
        local[0] = '\0';
    }
    remove_newline(local);

    pthread_mutex_lock(&sh->mtx);
    strncpy(sh->buf, local, MAX_STR - 1);
    sh->buf[MAX_STR - 1] = '\0';

    sh->lida = 1;
    pthread_cond_signal(&sh->cv_lida);
    pthread_mutex_unlock(&sh->mtx);

    return NULL;
}

void *thread_maiusculas(void *arg) {
    shared_t *sh = (shared_t *)arg;

    pthread_mutex_lock(&sh->mtx);
    while (!sh->lida) {
        pthread_cond_wait(&sh->cv_lida, &sh->mtx);
    }

    // Converter in-place para maiúsculas
    for (size_t i = 0; sh->buf[i] != '\0'; i++) {
        unsigned char c = (unsigned char)sh->buf[i];
        sh->buf[i] = (char)toupper(c);
    }

    sh->convertida = 1;
    pthread_cond_signal(&sh->cv_convertida);
    pthread_mutex_unlock(&sh->mtx);

    return NULL;
}

int main(void) {
    // Thread 0: o "main"
    pthread_t t_leitura, t_maiusculas;

    shared_t sh;
    memset(&sh, 0, sizeof(sh));

    if (pthread_mutex_init(&sh.mtx, NULL) != 0) {
        perror("pthread_mutex_init");
        return 1;
    }
    if (pthread_cond_init(&sh.cv_lida, NULL) != 0) {
        perror("pthread_cond_init");
        return 1;
    }
    if (pthread_cond_init(&sh.cv_convertida, NULL) != 0) {
        perror("pthread_cond_init");
        return 1;
    }

    // Criar threads (passagem de argumentos: &sh)
    if (pthread_create(&t_leitura, NULL, thread_leitura, &sh) != 0) {
        perror("pthread_create (leitura)");
        return 1;
    }
    if (pthread_create(&t_maiusculas, NULL, thread_maiusculas, &sh) != 0) {
        perror("pthread_create (maiusculas)");
        return 1;
    }

    // Thread 0 espera pela conversão e imprime (3ª tarefa)
    pthread_mutex_lock(&sh.mtx);
    while (!sh.convertida) {
        pthread_cond_wait(&sh.cv_convertida, &sh.mtx);
    }
    printf("String em maiúsculas: %s\n", sh.buf);
    pthread_mutex_unlock(&sh.mtx);

    // Encerrar threads
    pthread_join(t_leitura, NULL);
    pthread_join(t_maiusculas, NULL);

    pthread_cond_destroy(&sh.cv_lida);
    pthread_cond_destroy(&sh.cv_convertida);
    pthread_mutex_destroy(&sh.mtx);

    return 0;
}
