#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include<unistd.h>

#define NUM_THREADS	1

struct _Info{
    int Info;
};

void *AddHundred(void *_args)
{
    struct _Info *Data = (struct _Info *) _args;

    Data->Info = Data->Info + 100;
    printf("Child Thread: %d\n", Data->Info);
    pthread_exit(NULL);
}

int main(int argc, char *argv[])
{
    pthread_t threads;
    pthread_attr_t attr;
    int rc;
    void *status;

    /* Initialize and set thread detached attribute */
    pthread_attr_init(&attr);
    pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_JOINABLE);

    struct _Info *Info = calloc (sizeof (struct _Info), 1);
    Info->Info = 2023;
    printf("Main Thread: %d\n", Info->Info);

    printf("Creating thread %d\n", 1);
    rc = pthread_create(&threads, &attr, AddHundred, (void *) Info);
    if (rc) {
        printf("ERROR; return code from pthread_create() is %d\n", rc);
        exit(-1);
    }

    pthread_join(threads, &status);
    printf("Main Thread: %d\n", Info->Info);

    pthread_exit(NULL);
}