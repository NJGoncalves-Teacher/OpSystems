#define _POSIX_C_SOURCE 200809L
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

static void trim_newline(char *s) {
    size_t n = strlen(s);
    if (n > 0 && s[n - 1] == '\n') s[n - 1] = '\0';
}

/* Thread 1: lê a string e devolve-a (mensagem) ao thread 0 via join */
static void *thread_leitura(void *arg) {
    (void)arg;

    char *line = NULL;
    size_t cap = 0;

    printf("Introduza uma string: ");
    fflush(stdout);

    ssize_t n = getline(&line, &cap, stdin);
    if (n < 0) {
        free(line);
        // devolve string vazia em caso de EOF/erro
        char *empty = malloc(1);
        if (!empty) return NULL;
        empty[0] = '\0';
        return empty;
    }

    trim_newline(line);
    return line; // será libertada mais tarde pelo thread 0
}

/* Thread 2: recebe a string (mensagem), converte in-place e devolve-a */
static void *thread_maiusculas(void *arg) {
    char *s = (char *)arg;
    if (!s) return NULL;

    for (size_t i = 0; s[i] != '\0'; i++) {
        unsigned char c = (unsigned char)s[i];
        s[i] = (char)toupper(c);
    }
    return s; // devolve o mesmo apontador
}

int main(void) {
    // Thread 0 (main): coordena e imprime no fim
    pthread_t t1, t2;

    // 1) Leitura
    if (pthread_create(&t1, NULL, thread_leitura, NULL) != 0) {
        perror("pthread_create (leitura)");
        return 1;
    }

    void *msg1 = NULL;
    if (pthread_join(t1, &msg1) != 0) {
        perror("pthread_join (leitura)");
        return 1;
    }

    // 2) Maiúsculas (passagem de mensagem como argumento)
    if (pthread_create(&t2, NULL, thread_maiusculas, msg1) != 0) {
        perror("pthread_create (maiusculas)");
        free(msg1);
        return 1;
    }

    void *msg2 = NULL;
    if (pthread_join(t2, &msg2) != 0) {
        perror("pthread_join (maiusculas)");
        free(msg1);
        return 1;
    }

    // 3) Escrita (executada pelo thread 0)
    printf("String em maiúsculas: %s\n", (char *)msg2);

    free(msg2);
    return 0;
}
