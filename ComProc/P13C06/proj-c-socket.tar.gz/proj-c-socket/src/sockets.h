int ServerCreateConnection(unsigned short port, char *host, int connections);
int ClientCreateConnection(unsigned short port, char *host);