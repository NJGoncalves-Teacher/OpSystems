
#include <stdio.h>

#define NORMAL	0

int main()
{
    printf("Olá Mundo\n");

    return NORMAL;
}
