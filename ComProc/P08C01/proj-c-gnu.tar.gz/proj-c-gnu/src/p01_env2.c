#include <stdio.h>
#include <stdlib.h>

#define NORMAL	0

int main(int argc, char * argv[])
{
    int i;
    char *mode, *user;

    printf("Argumentos (%d):\n", argc);
    for( i = 0 ; i < argc ; i++ )
        printf("\targv[%d]=%s\n", i, argv[i]);

    puts("Variaveis de ambiente:");

    mode = getenv("MODE");
    if (!mode) mode = "normal";  // valor por defeito

    user = getenv("USER");       // exemplo adicional
    printf("MODE=%s, USER=%s\n", mode, user ? user : "(desconhecido)");

    return NORMAL;
}
