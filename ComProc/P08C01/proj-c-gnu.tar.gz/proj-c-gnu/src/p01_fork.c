#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>

#define SUCCESS 0
#define FAILURE 1

int main(void) {

    pid_t childpid;

    switch (childpid = fork()) {
    case -1:  // erro
        perror(strerror(errno));
        return FAILURE;

    case 0:   // filho
        printf("%d: Sou o filho \n", getpid());
        printf("%d: O pai \n", getppid());

        break;

    default:  // pai
        printf("%d: Sou o pai\n", getpid());
        printf("%d: O filho\n", childpid);
    }
    return SUCCESS;
}