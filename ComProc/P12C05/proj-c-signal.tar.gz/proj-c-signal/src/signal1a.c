#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <signal.h>

#define NORMAL	0

enum _BOOLEAN {FALSE = 0, TRUE = 1};
typedef enum _BOOLEAN BOOLEAN;

int nsair = TRUE;

void (*handler(int signal))(int sinal)
{
    switch (signal)
    {
    case SIGHUP: 
        puts("Programa recebeu um SIGHUP");
        break;
    case SIGINT: 
        puts("Programa recebeu um SIGINT");
        break;
    case SIGQUIT: 
        puts("Programa recebeu um SIGQUIT");
        nsair = FALSE;
        break;
    default:
        puts("Programa recebeu um sinal nao tratado");
    }
}

int main()
{
    signal(SIGHUP, (void (*)(int))handler);      //associar função ao sinal SIGHUP
    signal(SIGINT, (void (*)(int))handler);      //associar função ao sinal SIGHUP
    signal(SIGQUIT, (void (*)(int))handler);    //associar função ao sinal SIGQUIT
    signal(SIGUSR1, (void (*)(int))handler);    //associar função ao sinal SIGUSR1
    signal(SIGKILL, (void (*)(int))handler);    //associar função ao sinal SIGKILL
                                                //associacao SIGKILL nao funciona
    printf("Programa (processo %d) recebe os sinais SIGHUP, SIGINT e SIGQUIT\n", getpid());
    while (nsair)
        sleep(1);
    puts("Abandonado programa devido a um SIGQUIT");

    return NORMAL;
}