// pipe_unidirecional.c
#define _POSIX_C_SOURCE 200809L
#include <unistd.h>     // pipe, fork, read, write, close
#include <sys/wait.h>   // wait
#include <errno.h>
#include <string.h>     // strlen
#include <stdio.h>      // perror
#include <stdlib.h>     // exit

static void die(const char *msg) {
    perror(msg);
    _exit(1);
}

int main(void) {
    int fd[2];
    if (pipe(fd) == -1) die("pipe");

    pid_t pid = fork();
    if (pid < 0) die("fork");

    if (pid == 0) {
        // --- Processo filho: CONSUMIDOR (le do pipe e escreve em stdout) ---
        if (close(fd[1]) == -1) die("close fd[1] no filho"); // não escreve

        char buf[1024];
        for (;;) {
            ssize_t n = read(fd[0], buf, sizeof buf);
            if (n > 0) {
                // reenviar exatamente n bytes para stdout
                ssize_t off = 0;
                while (off < n) {
                    ssize_t m = write(STDOUT_FILENO, buf + off, (size_t)(n - off));
                    if (m < 0) die("write stdout no filho");
                    off += m;
                }
            } else if (n == 0) {
                // EOF: produtor fechou a escrita
                break;
            } else {
                if (errno == EINTR) continue;
                die("read no filho");
            }
        }

        if (close(fd[0]) == -1) die("close fd[0] no filho");
        _exit(0);
    } else {
        // --- Processo pai: PRODUTOR (escreve no pipe) ---
        if (close(fd[0]) == -1) die("close fd[0] no pai"); // não lê

        const char *msg1 = "Mensagem 1: exemplo de bytes a circular num único sentido.\n";
        const char *msg2 = "Mensagem 2: comunicação via pipe.\n";
        const char *msg3 = "Mensagem 3: fim do produtor.\n";

        const char *msgs[] = { msg1, msg2, msg3 };
        for (size_t i = 0; i < sizeof(msgs)/sizeof(msgs[0]); ++i) {
            const char *p = msgs[i];
            size_t len = strlen(p);
            size_t off = 0;
            while (off < len) {
                ssize_t n = write(fd[1], p + off, len - off);
                if (n < 0) {
                    if (errno == EINTR) continue;
                    die("write no pai");
                }
                off += (size_t)n;
            }
        }

        // Sinaliza EOF ao consumidor
        if (close(fd[1]) == -1) die("close fd[1] no pai");

        // Limpa o processo filho
        if (wait(NULL) < 0) die("wait");
    }

    return 0;
}