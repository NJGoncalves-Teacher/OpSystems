#include <stdio.h>
#include <ctype.h>
#include <unistd.h>
#include <string.h>

#define SUCCESS	0
#define FAILURE	1


#define NORMAL	0
#define ERROR	1

#define MAXBUFFER	80
#define PIPE_OUT	0
#define PIPE_IN		1

int main()
{
    int i, size;
    int p[2];
    char buffer[MAXBUFFER + 1];

    if (pipe(p) != -1)
    {
        switch (fork())
        {
            case -1:                                               /* erro no fork() */
            perror("Erro na criação do processo filho");
            break;
            case 0:                                                /* processo filho */
                printf("[%d]: ", getpid());
                fgets(buffer, MAXBUFFER, stdin);              /* inclui o carater \n */

                size = strlen(buffer);
                buffer[size - 1] = '\0';                           /* subs \n por \0 */

                write(p[PIPE_IN], &size, sizeof(int));               /* enviar texto */
                write(p[PIPE_IN], buffer, size);

                close(p[PIPE_IN]);
                close(p[PIPE_OUT]);

                break;
            default:                                                 /* processo pai */
                read(p[PIPE_OUT], &size, sizeof(int));           /* receber mensagem */
                read(p[PIPE_OUT], buffer, size);

                printf("[%d]: Texto introduzido - %s\n", getpid(), buffer);

                close(p[PIPE_IN]);
                close(p[PIPE_OUT]);
        }
    }
    else
    {
        perror("Erro na criação das pipes!");
        return FAILURE;
    }

    return SUCCESS;
}