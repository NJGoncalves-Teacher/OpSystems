\
/*
 * 07MsgQueueConversao.c
 * Conversão do exemplo 07ThConversao.c (argument passing via pthread_join)
 * para IPC via System V Message Queue.
 *
 * No original:
 *   - Thread 1 lê uma string e "devolve" (via pthread_exit/pthread_join) ao thread 0.
 *   - Thread 2 recebe a string, converte para maiúsculas e "devolve" ao thread 0.
 *   - Thread 0 imprime.
 *
 * Nesta conversão (analogia directa com join + retorno):
 *   1) Pai cria a message queue.
 *   2) Fork do "leitura": filho lê stdin e envia MSG_READ (mtype=1) ao pai, e termina.
 *      Pai faz msgrcv(mtype=1) + waitpid (equivalente a join).
 *   3) Fork do "maiusculas": pai envia ao filho a string lida (mtype=2).
 *      Filho recebe, converte, envia MSG_UPPER (mtype=3) ao pai, e termina.
 *      Pai faz msgrcv(mtype=3) + waitpid (equivalente a join).
 *   4) Pai imprime e remove a queue.
 *
 * Compilação:
 *   gcc -Wall -Wextra -O2 -std=c11 -o 07MsgQueueConversao 07MsgQueueConversao.c
 *
 * Execução:
 *   ./07MsgQueueConversao
 */

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

#define MAX_STR 256

enum { MSG_READ = 1, MSG_TO_CONVERT = 2, MSG_UPPER = 3 };

typedef struct {
    long mtype;
    char buf[MAX_STR];
} msg_str_t;

static void die_rmqueue(const char *what, int msqid) {
    int e = errno;
    if (msqid != -1) msgctl(msqid, IPC_RMID, NULL);
    fprintf(stderr, "ERRO: %s (errno=%d: %s)\n", what, e, strerror(e));
    exit(EXIT_FAILURE);
}

static void trim_newline(char *s) {
    size_t n = strlen(s);
    if (n > 0 && s[n - 1] == '\n') s[n - 1] = '\0';
}

static void do_uppercase(char *s) {
    for (; *s; ++s) *s = (char)toupper((unsigned char)*s);
}

int main(void) {
    int msqid = msgget(IPC_PRIVATE, 0600 | IPC_CREAT);
    if (msqid == -1) die_rmqueue("msgget() falhou", -1);

    /* 1) "thread_leitura" -> filho que envia a string ao pai */
    pid_t t1 = fork();
    if (t1 < 0) die_rmqueue("fork() (leitura) falhou", msqid);

    if (t1 == 0) {
        char local[MAX_STR];

        printf("Introduza uma string: ");
        fflush(stdout);

        if (!fgets(local, sizeof(local), stdin)) {
            local[0] = '\0';
        }
        trim_newline(local);

        msg_str_t m;
        m.mtype = MSG_READ;
        snprintf(m.buf, sizeof(m.buf), "%s", local);

        if (msgsnd(msqid, &m, sizeof(m) - sizeof(long), 0) == -1) {
            perror("msgsnd (leitura)");
            _exit(EXIT_FAILURE);
        }

        _exit(EXIT_SUCCESS);
    }

    /* "join" do t1 -> receber mensagem e esperar pelo filho */
    msg_str_t msg1;
    if (msgrcv(msqid, &msg1, sizeof(msg1) - sizeof(long), MSG_READ, 0) == -1) {
        die_rmqueue("msgrcv() (leitura) falhou", msqid);
    }
    int st = 0;
    if (waitpid(t1, &st, 0) == -1) die_rmqueue("waitpid(leitura) falhou", msqid);

    /* 2) "thread_maiusculas" -> filho que converte e devolve ao pai */
    pid_t t2 = fork();
    if (t2 < 0) die_rmqueue("fork() (maiusculas) falhou", msqid);

    if (t2 == 0) {
        msg_str_t in;
        if (msgrcv(msqid, &in, sizeof(in) - sizeof(long), MSG_TO_CONVERT, 0) == -1) {
            perror("msgrcv (para converter)");
            _exit(EXIT_FAILURE);
        }

        do_uppercase(in.buf);

        msg_str_t out;
        out.mtype = MSG_UPPER;
        snprintf(out.buf, sizeof(out.buf), "%s", in.buf);

        if (msgsnd(msqid, &out, sizeof(out) - sizeof(long), 0) == -1) {
            perror("msgsnd (maiusculas)");
            _exit(EXIT_FAILURE);
        }

        _exit(EXIT_SUCCESS);
    }

    /* "passar argumento" a t2 -> enviar string lida */
    msg_str_t to2;
    to2.mtype = MSG_TO_CONVERT;
    snprintf(to2.buf, sizeof(to2.buf), "%s", msg1.buf);

    if (msgsnd(msqid, &to2, sizeof(to2) - sizeof(long), 0) == -1) {
        die_rmqueue("msgsnd() (para converter) falhou", msqid);
    }

    /* "join" do t2 -> receber resultado e esperar pelo filho */
    msg_str_t msg2;
    if (msgrcv(msqid, &msg2, sizeof(msg2) - sizeof(long), MSG_UPPER, 0) == -1) {
        die_rmqueue("msgrcv() (maiusculas) falhou", msqid);
    }
    if (waitpid(t2, &st, 0) == -1) die_rmqueue("waitpid(maiusculas) falhou", msqid);

    /* 3) Escrita (executada pelo "thread 0" -> pai) */
    printf("String em maiúsculas: %s\n", msg2.buf);

    if (msgctl(msqid, IPC_RMID, NULL) == -1) die_rmqueue("msgctl(IPC_RMID) falhou", -1);

    return 0;
}
