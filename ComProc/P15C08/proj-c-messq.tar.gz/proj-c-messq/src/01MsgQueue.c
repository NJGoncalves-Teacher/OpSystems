\
/*
 * 01MsgQueue.c
 *
 * Ideia:
 *  - O processo pai cria uma message queue.
 *  - Cria NUM_WORKERS processos-filho (fork).
 *  - Cada filho envia uma mensagem "Hello World" para a queue e termina.
 *  - O pai lê NUM_WORKERS mensagens (msgrcv), imprime-as e faz cleanup (msgctl IPC_RMID).
 *
 * Compilação:
 *   gcc -Wall -Wextra -O2 -std=c11 -o 01MsgQueue 01MsgQueue.c
 *
 * Execução:
 *   ./01MsgQueue.exe
 */

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

#define NUM_WORKERS 5

/* Estrutura da mensagem (System V):
 * - o primeiro campo TEM de ser um long (mtype)
 * - o tamanho passado a msgsnd/msgrcv NÃO inclui o mtype
 */
typedef struct {
    long mtype;          /* tipo da mensagem (>0) */
    long worker_id;      /* id lógico do "worker" */
    pid_t pid;           /* PID do processo que enviou */
    char text[128];      /* payload */
} msg_t;

static void die(const char *msg) {
    int e = errno;
    fprintf(stderr, "ERRO: %s (errno=%d: %s)\n", msg, e, strerror(e));
    exit(EXIT_FAILURE);
}

int main(void) {
    int msqid = msgget(IPC_PRIVATE, 0600 | IPC_CREAT);
    if (msqid == -1) die("msgget() falhou");

    pid_t children[NUM_WORKERS];

    for (long t = 0; t < NUM_WORKERS; t++) {
        printf("In main: creating worker %ld\n", t);

        pid_t pid = fork();
        if (pid < 0) {
            /* Em caso de erro, remover a queue e abortar */
            msgctl(msqid, IPC_RMID, NULL);
            die("fork() falhou");
        }

        if (pid == 0) {
            /* Filho: envia 1 mensagem e termina */
            msg_t m;
            m.mtype = 1;               /* todos do mesmo tipo (1) */
            m.worker_id = t;
            m.pid = getpid();
            snprintf(m.text, sizeof(m.text),
                    "Hello World! It's me, worker #%ld (pid=%ld)!",
                    t, (long)m.pid);

            if (msgsnd(msqid, &m, sizeof(m) - sizeof(long), 0) == -1) {
                die("msgsnd() falhou no filho");
            }

            _exit(EXIT_SUCCESS);
        }

        /* Pai */
        children[t] = pid;
    }

    /* Pai: recebe e imprime NUM_WORKERS mensagens */
    for (int i = 0; i < NUM_WORKERS; i++) {
        msg_t m;
        ssize_t n = msgrcv(msqid, &m, sizeof(m) - sizeof(long), 0, 0);
        if (n == -1) {
            /* tentar remover antes de sair */
            msgctl(msqid, IPC_RMID, NULL);
            die("msgrcv() falhou");
        }

        /* Mantém o espírito do original: um "Hello World" por worker */
        printf("%s\n", m.text);
    }

    /* Esperar pelos filhos (boa prática) */
    for (int i = 0; i < NUM_WORKERS; i++) {
        int status = 0;
        if (waitpid(children[i], &status, 0) == -1) {
            msgctl(msqid, IPC_RMID, NULL);
            die("waitpid() falhou");
        }
        (void)status;
    }

    /* Cleanup: remover a message queue */
    if (msgctl(msqid, IPC_RMID, NULL) == -1) die("msgctl(IPC_RMID) falhou");

    return EXIT_SUCCESS;
}
