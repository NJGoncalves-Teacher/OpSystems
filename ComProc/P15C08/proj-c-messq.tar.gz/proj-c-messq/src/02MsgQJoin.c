\
/*
 * 02MsgQueueJoin.c
 * Conversão do exemplo 02ThJoin.c (pthread_create + pthread_join)
 * para IPC via System V Message Queue.
 *
 * Ideia (analogia com join):
 *  - O processo pai cria uma message queue.
 *  - Cria NUM_WORKERS processos-filho (fork).
 *  - Cada filho executa "BusyWork", envia o "status" (equivalente ao
 *    valor devolvido pelo pthread_exit) e termina.
 *  - O pai, em vez de pthread_join(thread[t], &status), faz:
 *      msgrcv(..., mtype=t+1, ...)  -> espera pela mensagem do worker t
 *      waitpid(pid_do_worker_t, ...) -> garante terminação/recolha (reap)
 *  - No fim, remove a queue (msgctl IPC_RMID).
 *
 * Compilação (nota: usa funções matemáticas -> -lm):
 *   gcc -Wall -Wextra -O2 -std=c11 -o 02MsgQueueJoin 02MsgQueueJoin.c -lm
 *
 * Execução:
 *   ./02MsgQueueJoin
 */

#include <errno.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

#define NUM_WORKERS 4
#define ITERATIONS  1000000

/* Estrutura de mensagem (System V):
 * - o primeiro campo TEM de ser long (mtype)
 * - o tamanho passado a msgsnd/msgrcv NÃO inclui o mtype
 */
typedef struct {
    long   mtype;       /* tipo: usa-se (worker_id + 1) para simular join por id */
    long   worker_id;   /* id lógico do "worker" */
    long   status;      /* status devolvido (analogia com pthread_join(...,&status)) */
    pid_t  pid;         /* PID do processo que executou o trabalho */
    double result;      /* resultado do "busy work" */
} msg_t;

static void die(const char *msg) {
    int e = errno;
    fprintf(stderr, "ERRO: %s (errno=%d: %s)\n", msg, e, strerror(e));
    exit(EXIT_FAILURE);
}

static double BusyWork(long wid) {
    double result = 0.0;

    printf("Worker %ld starting...\n", wid);

    for (int i = 0; i < ITERATIONS; i++) {
        /* Trabalho "artificial" semelhante ao exemplo clássico de pthread_join */
        result += sin((double)i) * tan((double)i);
    }

    printf("Worker %ld done. Result = %e\n", wid, result);
    return result;
}

int main(void) {
    int msqid = msgget(IPC_PRIVATE, 0600 | IPC_CREAT);
    if (msqid == -1) die("msgget() falhou");

    pid_t children[NUM_WORKERS];

    /* "Criar threads" -> aqui: criar processos-filho */
    for (long t = 0; t < NUM_WORKERS; t++) {
        printf("Main: creating worker %ld\n", t);

        pid_t pid = fork();
        if (pid < 0) {
            msgctl(msqid, IPC_RMID, NULL);
            die("fork() falhou");
        }

        if (pid == 0) {
            /* Filho: executa busy work e envia mensagem */
            msg_t m;
            m.worker_id = t;
            m.pid = getpid();
            m.result = BusyWork(t);

            /* Status equivalente ao valor retornado pela thread; no exemplo típico, é (void*)t */
            m.status = t;

            /* mtype = t+1 para permitir que o pai "faça join" por id (msgrcv com tipo específico) */
            m.mtype = t + 1;

            if (msgsnd(msqid, &m, sizeof(m) - sizeof(long), 0) == -1) {
                die("msgsnd() falhou no filho");
            }

            _exit(EXIT_SUCCESS);
        }

        /* Pai: guardar PID do worker */
        children[t] = pid;
    }

    /* "pthread_join" -> aqui: receber mensagem do worker e reap do processo correspondente */
    for (long t = 0; t < NUM_WORKERS; t++) {
        msg_t m;
        ssize_t n = msgrcv(msqid, &m, sizeof(m) - sizeof(long), t + 1, 0);
        if (n == -1) {
            msgctl(msqid, IPC_RMID, NULL);
            die("msgrcv() falhou");
        }

        /* Garantir que o processo terminou (analogia com join bloquear até fim) */
        int status_proc = 0;
        if (waitpid(children[t], &status_proc, 0) == -1) {
            msgctl(msqid, IPC_RMID, NULL);
            die("waitpid() falhou");
        }
        (void)status_proc;

        printf("Main: completed join with worker %ld having a status of %ld\n",
               t, m.status);
    }

    printf("Main: program completed. Exiting.\n");

    if (msgctl(msqid, IPC_RMID, NULL) == -1) die("msgctl(IPC_RMID) falhou");

    return EXIT_SUCCESS;
}
