\
/*
 * 06MsgQueueConversao.c
 * Conversão do exemplo 06ThConversao.c (threads + mutex + condition variables)
 * para IPC via System V Message Queue.
 *
 * Mapeamento conceptual:
 *   - Thread 1 (leitura)  -> processo-filho "leitura"
 *   - Thread 2 (conversão)-> processo-filho "maiusculas"
 *   - Thread 0 (main)     -> processo pai (imprime o resultado)
 *
 * Em vez de partilha de memória + cond vars, usa-se:
 *   - msgsnd(): sinaliza/transporta "string lida"
 *   - msgsnd(): sinaliza/transporta "string convertida"
 *
 * Fluxo:
 *   1) Pai cria a message queue.
 *   2) Pai cria dois filhos: leitura e maiusculas.
 *   3) Leitura: lê stdin e envia a string (mtype=1).
 *   4) Maiusculas: recebe (mtype=1), converte e envia (mtype=2).
 *   5) Pai: recebe (mtype=2) e imprime.
 *
 * Compilação:
 *   gcc -Wall -Wextra -O2 -std=c11 -o 06MsgQueueConversao 06MsgQueueConversao.c
 *
 * Execução:
 *   ./06MsgQueueConversao
 */

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

#define MAX_STR 256

typedef struct {
    long mtype;          /* 1: "lida", 2: "convertida" */
    char buf[MAX_STR];
} msg_str_t;

static void die_rmqueue(const char *what, int msqid) {
    int e = errno;
    if (msqid != -1) msgctl(msqid, IPC_RMID, NULL);
    fprintf(stderr, "ERRO: %s (errno=%d: %s)\n", what, e, strerror(e));
    exit(EXIT_FAILURE);
}

static void trim_newline(char *s) {
    size_t n = strlen(s);
    if (n > 0 && s[n - 1] == '\n') s[n - 1] = '\0';
}

static void do_uppercase(char *s) {
    for (; *s; ++s) *s = (char)toupper((unsigned char)*s);
}

int main(void) {
    int msqid = msgget(IPC_PRIVATE, 0600 | IPC_CREAT);
    if (msqid == -1) die_rmqueue("msgget() falhou", -1);

    pid_t pid_leitura = fork();
    if (pid_leitura < 0) die_rmqueue("fork() (leitura) falhou", msqid);

    if (pid_leitura == 0) {
        /* Processo "leitura" */
        char local[MAX_STR];

        printf("Introduza uma string: ");
        fflush(stdout);

        if (!fgets(local, sizeof(local), stdin)) {
            /* EOF/erro: enviar string vazia para não bloquear a cadeia */
            local[0] = '\0';
        }
        trim_newline(local);

        msg_str_t m;
        m.mtype = 1;
        snprintf(m.buf, sizeof(m.buf), "%s", local);

        if (msgsnd(msqid, &m, sizeof(m) - sizeof(long), 0) == -1) {
            perror("msgsnd (lida)");
            _exit(EXIT_FAILURE);
        }

        _exit(EXIT_SUCCESS);
    }

    pid_t pid_maiusculas = fork();
    if (pid_maiusculas < 0) die_rmqueue("fork() (maiusculas) falhou", msqid);

    if (pid_maiusculas == 0) {
        /* Processo "maiusculas" */
        msg_str_t in;
        if (msgrcv(msqid, &in, sizeof(in) - sizeof(long), 1, 0) == -1) {
            perror("msgrcv (lida)");
            _exit(EXIT_FAILURE);
        }

        do_uppercase(in.buf);

        msg_str_t out;
        out.mtype = 2;
        snprintf(out.buf, sizeof(out.buf), "%s", in.buf);

        if (msgsnd(msqid, &out, sizeof(out) - sizeof(long), 0) == -1) {
            perror("msgsnd (convertida)");
            _exit(EXIT_FAILURE);
        }

        _exit(EXIT_SUCCESS);
    }

    /* Processo pai: recebe a string convertida e imprime (equivalente ao thread 0) */
    msg_str_t out;
    if (msgrcv(msqid, &out, sizeof(out) - sizeof(long), 2, 0) == -1) {
        die_rmqueue("msgrcv() (convertida) falhou", msqid);
    }

    printf("String em maiúsculas: %s\n", out.buf);

    /* Recolher filhos */
    int st = 0;
    if (waitpid(pid_leitura, &st, 0) == -1) die_rmqueue("waitpid(leitura) falhou", msqid);
    if (waitpid(pid_maiusculas, &st, 0) == -1) die_rmqueue("waitpid(maiusculas) falhou", msqid);

    /* Remover a queue */
    if (msgctl(msqid, IPC_RMID, NULL) == -1) die_rmqueue("msgctl(IPC_RMID) falhou", -1);

    return 0;
}
