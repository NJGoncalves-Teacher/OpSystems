\
/*
 * 04MsgQueueArgPassing.c
 * Conversão do exemplo 04ThArgPassing.c (Blaise Barney: hello_arg1.c)
 * para IPC via System V Message Queue.
 *
 * O exemplo original demonstra uma forma "segura" de passar argumentos para threads
 * (cada thread recebe um ponteiro para a sua própria estrutura de dados).
 *
 * Nesta conversão:
 *  - O processo pai cria uma message queue (System V).
 *  - Cria NUM_WORKERS processos-filho (fork).
 *  - Para cada filho, o pai envia uma estrutura com os "argumentos" (thread_id, sum, message)
 *    através da queue (mtype = PID do filho).
 *  - Cada filho recebe os seus argumentos, imprime o equivalente ao PrintHello() e envia
 *    um ACK ao pai (mtype = PID do pai). O pai espera todos os ACKs e faz waitpid().
 *
 * Compilação:
 *   gcc -Wall -Wextra -O2 -std=c11 -o 04MsgQueueArgPassing 04MsgQueueArgPassing.c
 *
 * Execução:
 *   ./04MsgQueueArgPassing
 */

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

#define NUM_WORKERS 8

/* Mensagem com argumentos (equivalente ao argumento passado para a thread) */
typedef struct {
    long mtype;              /* tipo: PID do filho */
    int  thread_id;
    int  sum;
    char message[128];
} msg_args_t;

/* Mensagem de confirmação para o pai */
typedef struct {
    long  mtype;             /* tipo: PID do pai */
    int   thread_id;
    pid_t pid;
} msg_ack_t;

static void die(const char *what) {
    int e = errno;
    fprintf(stderr, "ERRO: %s (errno=%d: %s)\n", what, e, strerror(e));
    exit(EXIT_FAILURE);
}

int main(void) {
    /* Conjunto típico de mensagens usado nos exemplos didáticos */
    const char *messages[NUM_WORKERS] = {
        "English: Hello World!",
        "French: Bonjour, le monde!",
        "Spanish: Hola al mundo!",
        "Klingon: Nuq neH!",
        "German: Guten Tag, Welt!",
        "Russian: Zdravstvuyte, mir!",
        "Japan: Sekai e konnichiwa!",
        "Latin: Orbis, te saluto!"
    };

    pid_t parent_pid = getpid();

    int msqid = msgget(IPC_PRIVATE, 0600 | IPC_CREAT);
    if (msqid == -1) die("msgget() falhou");

    pid_t children[NUM_WORKERS];

    int sum = 0;

    /* "Criar threads" -> aqui: criar processos-filho e enviar argumentos por MQ */
    for (int t = 0; t < NUM_WORKERS; t++) {
        sum = sum + t;

        printf("Creating thread %d\n", t);

        pid_t pid = fork();
        if (pid < 0) {
            msgctl(msqid, IPC_RMID, NULL);
            die("fork() falhou");
        }

        if (pid == 0) {
            /* Filho: recebe argumentos direcionados ao seu PID */
            msg_args_t a;
            if (msgrcv(msqid, &a, sizeof(a) - sizeof(long), (long)getpid(), 0) == -1) {
                die("msgrcv() (args) falhou no filho");
            }

            /* Simula trabalho/latência (frequente em exemplos) */
            sleep(1);

            /* Equivalente ao PrintHello() do exemplo pthreads */
            printf("Thread %d: sum=%d message=%s\n", a.thread_id, a.sum, a.message);

            /* Envia ACK ao pai (para manter o processo vivo até terminar tudo, análogo a pthread_exit) */
            msg_ack_t ack;
            ack.mtype = (long)parent_pid;
            ack.thread_id = a.thread_id;
            ack.pid = getpid();

            if (msgsnd(msqid, &ack, sizeof(ack) - sizeof(long), 0) == -1) {
                die("msgsnd() (ack) falhou no filho");
            }

            _exit(EXIT_SUCCESS);
        }

        /* Pai: guarda PID e envia argumentos para o filho */
        children[t] = pid;

        msg_args_t a;
        a.mtype = (long)pid;      /* PID do filho */
        a.thread_id = t;
        a.sum = sum;
        snprintf(a.message, sizeof(a.message), "%s", messages[t]);

        if (msgsnd(msqid, &a, sizeof(a) - sizeof(long), 0) == -1) {
            msgctl(msqid, IPC_RMID, NULL);
            die("msgsnd() (args) falhou no pai");
        }
    }

    /* Pai: espera pelos ACKs (equivalente prático a "pthread_exit" no main) */
    for (int i = 0; i < NUM_WORKERS; i++) {
        msg_ack_t ack;
        if (msgrcv(msqid, &ack, sizeof(ack) - sizeof(long), (long)parent_pid, 0) == -1) {
            msgctl(msqid, IPC_RMID, NULL);
            die("msgrcv() (ack) falhou no pai");
        }
        (void)ack;
    }

    /* Recolher filhos */
    for (int t = 0; t < NUM_WORKERS; t++) {
        int status = 0;
        if (waitpid(children[t], &status, 0) == -1) {
            msgctl(msqid, IPC_RMID, NULL);
            die("waitpid() falhou");
        }
        (void)status;
    }

    /* Remover a message queue */
    if (msgctl(msqid, IPC_RMID, NULL) == -1) die("msgctl(IPC_RMID) falhou");

    return EXIT_SUCCESS;
}
