\
/*
 * 03MsgQueueArgPassing.c
 * Conversão do exemplo 03ThArgPassing.c (argument passing em pthreads)
 * para IPC via System V Message Queue.
 *
 * Ideia:
 *  - O processo pai cria uma message queue.
 *  - Cria NUM_WORKERS processos-filho (fork).
 *  - Para cada filho, o pai envia um "pacote de argumentos" (taskid + mensagem)
 *    através da queue (mtype = PID do filho). Isto espelha o "argument passing"
 *    de pthread_create(..., arg).
 *  - Cada filho recebe os seus argumentos, imprime a mensagem, e envia um ACK
 *    ao pai (mtype = PID do pai), permitindo ao pai sincronizar de forma simples.
 *  - No fim, o pai faz waitpid() e remove a queue (msgctl IPC_RMID).
 *
 * Compilação:
 *   gcc -Wall -Wextra -O2 -std=c11 -o 03MsgQueueArgPassing 03MsgQueueArgPassing.c
 *
 * Execução:
 *   ./03MsgQueueArgPassing
 */

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

#define NUM_WORKERS 8

/* Mensagem de argumentos (equivalente ao arg passado no pthread_create) */
typedef struct {
    long mtype;          /* usa-se o PID do filho como tipo */
    int  taskid;         /* id lógico do "worker" */
    char text[128];      /* mensagem associada ao worker */
} msg_args_t;

/* Mensagem de confirmação (ACK) para o pai */
typedef struct {
    long  mtype;         /* usa-se o PID do pai como tipo */
    int   taskid;
    pid_t pid;
} msg_ack_t;

static void die(const char *what) {
    int e = errno;
    fprintf(stderr, "ERRO: %s (errno=%d: %s)\n", what, e, strerror(e));
    exit(EXIT_FAILURE);
}

int main(void) {
    /* Mensagens (mantendo o espírito do exemplo clássico) */
    const char *messages[NUM_WORKERS] = {
        "English: Hello World!",
        "French: Bonjour, le monde!",
        "Spanish: Hola al mundo!",
        "Klingon: Nuq neH!",
        "German: Guten Tag, Welt!",
        "Russian: Zdravstvuyte, mir!",
        "Japan: Sekai e konnichiwa!",
        "Latin: Orbis, te saluto!"
    };

    pid_t parent_pid = getpid();

    int msqid = msgget(IPC_PRIVATE, 0600 | IPC_CREAT);
    if (msqid == -1) die("msgget() falhou");

    pid_t children[NUM_WORKERS];

    /* Criar processos-filho e "passar argumentos" via message queue */
    for (int t = 0; t < NUM_WORKERS; t++) {
        printf("Creating thread %d\n", t); /* linha mantida para equivalência */

        pid_t pid = fork();
        if (pid < 0) {
            msgctl(msqid, IPC_RMID, NULL);
            die("fork() falhou");
        }

        if (pid == 0) {
            /* Filho: recebe argumentos dirigidos ao seu PID */
            msg_args_t a;
            if (msgrcv(msqid, &a, sizeof(a) - sizeof(long), (long)getpid(), 0) == -1) {
                die("msgrcv() (args) falhou no filho");
            }

            /* Simula ligeiro atraso, comum em exemplos didáticos */
            sleep(1);

            printf("Thread %d: %s\n", a.taskid, a.text);

            /* Envia ACK ao pai */
            msg_ack_t ack;
            ack.mtype = (long)parent_pid;
            ack.taskid = a.taskid;
            ack.pid = getpid();

            if (msgsnd(msqid, &ack, sizeof(ack) - sizeof(long), 0) == -1) {
                die("msgsnd() (ack) falhou no filho");
            }

            _exit(EXIT_SUCCESS);
        }

        /* Pai: guarda PID e envia argumentos para o filho */
        children[t] = pid;

        msg_args_t a;
        a.mtype = (long)pid;      /* tipo = PID do filho */
        a.taskid = t;
        snprintf(a.text, sizeof(a.text), "%s", messages[t]);

        if (msgsnd(msqid, &a, sizeof(a) - sizeof(long), 0) == -1) {
            msgctl(msqid, IPC_RMID, NULL);
            die("msgsnd() (args) falhou no pai");
        }
    }

    /* Pai: aguarda NUM_WORKERS ACKs (sincronização semelhante a join/terminação) */
    for (int i = 0; i < NUM_WORKERS; i++) {
        msg_ack_t ack;
        if (msgrcv(msqid, &ack, sizeof(ack) - sizeof(long), (long)parent_pid, 0) == -1) {
            msgctl(msqid, IPC_RMID, NULL);
            die("msgrcv() (ack) falhou no pai");
        }
        /* opcional: confirmar receção */
        /* printf("Main: recebeu ACK do worker %d (pid=%ld)\n", ack.taskid, (long)ack.pid); */
        (void)ack;
    }

    /* Boa prática: reap dos filhos */
    for (int t = 0; t < NUM_WORKERS; t++) {
        int status = 0;
        if (waitpid(children[t], &status, 0) == -1) {
            msgctl(msqid, IPC_RMID, NULL);
            die("waitpid() falhou");
        }
        (void)status;
    }

    /* Remover a message queue */
    if (msgctl(msqid, IPC_RMID, NULL) == -1) die("msgctl(IPC_RMID) falhou");

    return EXIT_SUCCESS;
}
