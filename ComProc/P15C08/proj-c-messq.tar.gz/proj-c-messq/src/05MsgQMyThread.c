\
/*
 * 05MsgQueueMyThread.c
 * Conversão do exemplo 05MyThread.c (pthread) para IPC via System V Message Queue.
 *
 * Nota:
 *   O ficheiro 05MyThread.c fornecido encontra-se truncado (contém "..." no corpo da função).
 *   Esta versão mantém a intenção visível: uma "thread" recebe um argumento (struct _Info),
 *   soma 100 ao campo Info e o "main" imprime o valor antes/depois.
 *
 * Nesta conversão:
 *   - O processo pai cria uma message queue.
 *   - Cria um processo-filho (fork) que faz o papel da "thread".
 *   - O pai envia o valor Info ao filho (argument passing).
 *   - O filho soma 100 e envia o valor actualizado de volta ao pai.
 *   - O pai imprime o valor actualizado, espera pelo filho e remove a queue.
 *
 * Compilação:
 *   gcc -Wall -Wextra -O2 -std=c11 -o 05MsgQueueMyThread 05MsgQueueMyThread.c
 *
 * Execução:
 *   ./05MsgQueueMyThread
 */

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

struct _Info {
    int Info;
};

/* Mensagem simples para transportar o valor */
typedef struct {
    long mtype;   /* obrigatório em System V */
    int  value;   /* payload */
} msg_int_t;

static void die(const char *what) {
    int e = errno;
    fprintf(stderr, "ERRO: %s (errno=%d: %s)\n", what, e, strerror(e));
    exit(EXIT_FAILURE);
}

/* "Thread function" -> aqui: função executada no processo-filho */
static int AddHundred(int x) {
    return x + 100;
}

int main(void) {
    struct _Info info;
    info.Info = 2023;

    printf("Main Thread: %d\n", info.Info);

    /* Criar message queue privada */
    int msqid = msgget(IPC_PRIVATE, 0600 | IPC_CREAT);
    if (msqid == -1) die("msgget() falhou");

    printf("Creating thread %d\n", 1);

    pid_t pid = fork();
    if (pid < 0) {
        msgctl(msqid, IPC_RMID, NULL);
        die("fork() falhou");
    }

    if (pid == 0) {
        /* Filho: recebe argumento (mtype=1), processa e devolve (mtype=2) */
        msg_int_t in;
        if (msgrcv(msqid, &in, sizeof(in) - sizeof(long), 1, 0) == -1) {
            die("msgrcv() falhou no filho");
        }

        int updated = AddHundred(in.value);

        msg_int_t out;
        out.mtype = 2;
        out.value = updated;

        if (msgsnd(msqid, &out, sizeof(out) - sizeof(long), 0) == -1) {
            die("msgsnd() falhou no filho");
        }

        _exit(EXIT_SUCCESS);
    }

    /* Pai: envia argumento ao "worker" */
    msg_int_t in;
    in.mtype = 1;
    in.value = info.Info;

    if (msgsnd(msqid, &in, sizeof(in) - sizeof(long), 0) == -1) {
        msgctl(msqid, IPC_RMID, NULL);
        die("msgsnd() falhou no pai");
    }

    /* Pai: recebe resultado (equivalente a observar a struct alterada após join) */
    msg_int_t out;
    if (msgrcv(msqid, &out, sizeof(out) - sizeof(long), 2, 0) == -1) {
        msgctl(msqid, IPC_RMID, NULL);
        die("msgrcv() falhou no pai");
    }

    info.Info = out.value;
    printf("Main Thread: %d\n", info.Info);

    /* Recolher filho (boa prática) */
    int status = 0;
    if (waitpid(pid, &status, 0) == -1) {
        msgctl(msqid, IPC_RMID, NULL);
        die("waitpid() falhou");
    }
    (void)status;

    /* Remover a queue */
    if (msgctl(msqid, IPC_RMID, NULL) == -1) die("msgctl(IPC_RMID) falhou");

    return EXIT_SUCCESS;
}
