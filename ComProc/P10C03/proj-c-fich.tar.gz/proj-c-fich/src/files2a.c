#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>

#define NORMAL	0
#define ERROR	1

#define MAXLINE	80

int main()
{
  int comfile, size;
  char buffer[MAXLINE + 1];
  char com[] = "comfile";
  
  comfile = creat(com, S_IRWXU);             /* criar ficheiro temporario */

  if (comfile != -1)
   {
    fgets(buffer, MAXLINE, stdin);                 /* inclui o carater \n */
    if (strchr(buffer, '\n') != NULL)              /* se string contem \n */
      *(strchr(buffer, '\n')) = '\0';     /* substituir por fim de string */
    size = strlen(buffer);
    write(comfile , &size, sizeof(int));
    write(comfile , buffer, size);
       
    close(comfile);
    unlink(com);
   }
   else
   {
    perror("Erro no ficheiro temporario");
    return ERROR;
   }

  return NORMAL;
}
