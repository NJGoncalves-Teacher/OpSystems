#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "sockets.h"

#define NORMAL		0
#define ERROR		1
#define MAXLINE		128
#define MAXHOSTNAME	255

int main(int argc,char *argv[])
{
    int i = 0, mysocket, port;
    char ch, buffer[MAXLINE + 1], * host;

    if (argc < 3)
    {
        fprintf(stderr, "uso: %s maquina porta\n", argv[0]);
        return ERROR;
    }

    host = argv[1];
    port = atoi(argv[2]);
    if ((mysocket = ClientCreateConnection(port, host)) < 0)
    {
        perror("ClientCreateConnection: ");
        return ERROR;
    }

    printf("Ligacao ao servidor %s:%d (socket %d)\n", host, port, mysocket);

    do
    {
        read(mysocket, &buffer[i], sizeof(char));
    } while (buffer[i++] != '\n');
    buffer[i] = '\0';
    printf("%s", buffer);

    fgets(buffer, MAXLINE, stdin);                          //inclui o caracter \n

    write(mysocket, buffer, strlen(buffer));             //enviar texto ao servidor
    read(mysocket, buffer, strlen(buffer)); //receber texto convertido do servirdor

    close(mysocket);
    printf("%s", buffer);
    
    return NORMAL;
}