#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <signal.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/wait.h>

#include "sockets.h"

#define NORMAL			0
#define ERROR			1
#define MAXMESSAGE		128
#define MAXCONNECTIONS  1

void (*handlerHUP(int signal))(int sinal)
{
  puts("Servidor recebeu um SIGHUP");
  exit(0);
}

int main(int argc, char * argv[])
{
  int com, port, i, size, mysocket;
  char * host, buffer[MAXMESSAGE + 1];

  if (argc > 2)
   {
    host = argv[1];
    port = atoi(argv[2]); 
    if ((mysocket = ServerCreateConnection(port, host, MAXCONNECTIONS)) < 0)
     {
      perror("ServerCreateConnection: ");
      return ERROR;
     }

    signal(SIGHUP, (void (*)()) handlerHUP);

    fclose(stdin);
    printf("[%d]: Servidor em %s:%d\nEsperando comunicacoes (%d max) / SIGHUP termina\n", \
           getpid(), host, port, MAXCONNECTIONS);    //msg do servidor no stdout

    if ((com = accept(mysocket, NULL, NULL)) < 0)     //esperar pela comunicacao
     {
      perror("accept: ");
      return ERROR;
     }

    printf("[%d]: Comunicacao establecida\n", getpid());
    do
    {
      read(com, &size, sizeof(int));                     //obter dim da mensagem
      read(com, buffer, size);                                  //obter mensagem
      buffer[size] = '\0';                               //colocar fim de string

      for( i = 0 ; i < size ; i++)                                   //converter
        buffer[i] = toupper(buffer[i]);

      write(com, buffer, size); //enviar mensagem convertida de volta ao cliente
      printf("[%d]: %s (size = %d)\n", getpid(), buffer, size); //info no stdout 
 //   } while (strcasecmp(buffer, "sair") != 0);
    } while (size > 0);                            //versoa siar com tetxo vazio
    close(com);                                             //fechar comunicacao
   }
   else
   {
    fprintf(stderr,"uso: %s interface porta\n", argv[0]);
    return ERROR;
   }

  return NORMAL;
}
